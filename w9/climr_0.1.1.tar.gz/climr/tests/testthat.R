library(testthat)
library(climr)

test_check("climr")
