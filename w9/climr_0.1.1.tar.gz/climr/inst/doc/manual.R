## ------------------------------------------------------------------------
library(climr)
ans1 = load_clim('SH')
ans2 = fit(ans1)
plot(ans2)
ans3 = fit(ans1, data_type = 'monthly', fit_type = 'smooth.spline')
plot(ans3)
ans4 = fit(ans1, data_type = 'quarterly', fit_type = 'loess')
plot(ans4)

