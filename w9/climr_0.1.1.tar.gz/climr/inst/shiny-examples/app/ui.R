# Web app for the climr package

library(shiny)
library(climr)

# Define UI for application that draws a histogram
shinyUI(fluidPage(

  # Application title
  titlePanel("Climate change analysis in R"),

  # Sidebar with a slider input for number of bins
  sidebarLayout(
    sidebarPanel(
       selectInput("data",
                   "Data type",
                   choices = list("Global" = "GLB",
                                  "Northern hemisphere" = "NH",
                                  "Southern hemisphere" = "SH"),
                   selected = "GLB"),
       selectInput("smoother",
                   "Smoother type",
                   choices = list("Linear regression" = "lm",
                                  "Loess smooth" = "loess",
                                  "Spline smooth" = "smooth.spline"),
                   selected = "loess"),
       selectInput("scale",
                   "Scale type",
                   choices = list("Yearly" = "yearly",
                                  "Quarterly" = "quarterly",
                                  "Monthly" = "monthly"),
                   selected = "monthly"),
       sliderInput("grid",
                   "Number of time grid points",
                   min = 10,
                   max = 200,
                   value = 100)
    ),

    # Show a plot of the generated distribution
    mainPanel(
       plotOutput("distPlot")
    )
  )
))
