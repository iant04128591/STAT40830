#' Shiny app for the climr package
#'
#' @return Runs the Shiny app
#' @export
#'
#' @examples
#' \dontrun{
#' climr_shiny()
#' }
climr_shiny = function() {
  app_dir = system.file('shiny-examples', 'app', package = 'climr')

  shiny::runApp(app_dir, display.mode = 'normal')

}
