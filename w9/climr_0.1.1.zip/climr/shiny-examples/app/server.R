# Server function for climr package shiny app

library(shiny)
library(climr)

# Define server logic required to draw a histogram
shinyServer(function(input, output) {

  output$distPlot <- renderPlot({
    data_climr = load_clim(input$data)
    fit_climr = fit(data_climr,
                    data_type = input$scale,
                    fit_type = input$smoother)
    plot(fit_climr,
         time_grid = pretty(fit_climr$data$x,
                            n = input$grid))

  })

})
